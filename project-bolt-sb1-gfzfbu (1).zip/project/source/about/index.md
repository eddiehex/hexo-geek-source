---
title: About
layout: page
---

# About Me

Welcome to my geek blog! This is where I share my thoughts about technology, programming, and other geeky stuff.